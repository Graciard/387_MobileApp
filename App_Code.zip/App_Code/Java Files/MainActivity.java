package com.example.ece387app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button video1;
    private Button video2;
    private Button video3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        video1 = (Button) findViewById(R.id.video1);
        video2 = (Button) findViewById(R.id.video2);
        video3 = (Button) findViewById(R.id.video3);

        TextView textView = (TextView) findViewById(R.id.text);

        textView.setText("Use the buttons below to navigate to different videos from the EEFlight Youtube Channel.");

        video1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo1();
            }
        });

        video2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo2();
            }
        });

        video3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideo3();
            }
        });
    }
    public void openVideo1() {
        Intent intent = new Intent(this, VideoPage1.class);
        startActivity(intent);
    }

    public void openVideo2() {
        Intent intent2 = new Intent(this, VideoPage2.class);
        startActivity(intent2);
    }

    public void openVideo3() {
        Intent intent3 = new Intent(this, VideoPage3.class);
        startActivity(intent3);
    }
}